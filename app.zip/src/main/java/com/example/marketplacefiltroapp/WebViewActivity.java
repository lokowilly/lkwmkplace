package com.example.marketplacefiltroapp;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class WebViewActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        String brand = getIntent().getStringExtra("brand").toLowerCase();
        String year = getIntent().getStringExtra("year");
        String exclude = getIntent().getStringExtra("exclude").toLowerCase();

        WebView webView = findViewById(R.id.webview);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        webView.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView view, String url) {
                String[] words = exclude.split(",");
                StringBuilder js = new StringBuilder("javascript:(function() { ");
                js.append("let palabras = [");

                for (int i = 0; i < words.length; i++) {
                    js.append("'").append(words[i].trim()).append("'");
                    if (i != words.length - 1) js.append(",");
                }

                js.append("];");
                js.append("document.querySelectorAll('[role="article"]').forEach(el => {");
                js.append("let texto = el.innerText.toLowerCase();");
                js.append("if (texto.includes('").append(brand).append("') && texto.includes('").append(year).append("')) {");
                js.append("if (palabras.some(p => texto.includes(p))) { el.style.display = 'none'; }} else { el.style.display = 'none'; } });");
                js.append("})()");
                view.evaluateJavascript(js.toString(), null);
            }
        });

        webView.loadUrl("https://www.facebook.com/marketplace/");
    }
}
