package com.example.marketplacefiltroapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText brandInput = findViewById(R.id.brandInput);
        EditText yearInput = findViewById(R.id.yearInput);
        EditText excludeInput = findViewById(R.id.excludeInput);
        Button applyButton = findViewById(R.id.applyButton);

        applyButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
            intent.putExtra("brand", brandInput.getText().toString());
            intent.putExtra("year", yearInput.getText().toString());
            intent.putExtra("exclude", excludeInput.getText().toString());
            startActivity(intent);
        });
    }
}
